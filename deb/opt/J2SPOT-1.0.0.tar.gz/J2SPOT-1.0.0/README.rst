J2SPOT quickstart!!!...
=======================

J2SPOT is  a simple TCP honeypot for your system written in Python3.

Source code:
############

https://github.com/codingpsych72/J2SPOT

Documentation:
@@@@@@@@@@@@@@

Find the document at : 
https://J2SPOT.rtfd.io

Document can also be found in the "docs/" directory as a 
restructured text file .Build the docs by running the "make" command
 in the "docs/ directory" --then view the docs/_build/html/index.html
 
 Done as a mini-project for the semester examination:
  